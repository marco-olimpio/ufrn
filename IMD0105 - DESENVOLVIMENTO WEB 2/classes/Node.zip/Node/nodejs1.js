function ola(name) {
	console.log("Ola " + name);
}

ola("Pessoal");