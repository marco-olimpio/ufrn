var modulo = require('./modulo1.js');
console.log('Utilizando o modulo:' + modulo.dataAtual());

