exports.dataAtual = function () {
    return Date();
}