var  todo-list = [
    {
        "tarefa": "Projeto WS",
        "responsavel" : "João",
        "prazo" : "12/11/18"
    },
      {
        "tarefa": "BPM PDI",
        "responsavel" : "Maria",
        "prazo" : "21/11/18"
    },
      {
        "tarefa": "Projeto EDUC",
        "responsavel" : "Carlos",
        "prazo" : "28/11/18"
    },
      {
        "tarefa": "Plabilha Gastos PD",
        "responsavel" : "Teresa",
        "prazo" : "9/11/18"
    }
]
        
